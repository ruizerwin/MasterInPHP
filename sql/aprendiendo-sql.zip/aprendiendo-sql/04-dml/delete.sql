#BORRAR REGISTROS#
DELETE FROM usuarios WHERE email = 'admin@admin.com';
