/* 
4. Sacar todos los vendedores cuya fecha de alta sea posterior
al 1 de Julio de 2018
 */

SELECT * FROM vendedores WHERE fecha >= '2018-07-01';

