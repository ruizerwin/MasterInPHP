/* 
12. Conseguir la masa salarial del concesionario (anual)
 */
SELECT SUM(sueldo) as 'Masa Salarial' FROM vendedores;

