<?php
namespace MisClases;

class Entrada{
	public $titulo;
	public $fecha;
	
	public function __construct() {
		$this->titulo = "Review del GTA 5";
		$this->fecha = "5 de Mayo de 2020";
	}
}